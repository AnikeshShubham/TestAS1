import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Test Suites - Collections of test steps
export const testSuites = pgTable("test_suites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Test Steps - Individual automation commands within a suite
export const testSteps = pgTable("test_steps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  testSuiteId: varchar("test_suite_id").references(() => testSuites.id, { onDelete: 'cascade' }),
  description: text("description").notNull(),
  stepOrder: integer("step_order").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Test Runs - Executions of test suites
export const testRuns = pgTable("test_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  testSuiteId: varchar("test_suite_id").references(() => testSuites.id, { onDelete: 'cascade' }),
  status: text("status").notNull().default('pending'), // pending, running, completed, failed
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  totalSteps: integer("total_steps"),
  passedSteps: integer("passed_steps").default(0),
  failedSteps: integer("failed_steps").default(0),
});

// Test Step Results - Results of individual steps within a run
export const testStepResults = pgTable("test_step_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  testRunId: varchar("test_run_id").references(() => testRuns.id, { onDelete: 'cascade' }),
  stepOrder: integer("step_order").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull(), // pending, running, passed, failed
  duration: integer("duration"), // in milliseconds
  errorMessage: text("error_message"),
  logs: json("logs"), // Array of log messages
  screenshotPath: text("screenshot_path"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertTestSuiteSchema = createInsertSchema(testSuites).omit({
  id: true,
  createdAt: true,
});

export const insertTestStepSchema = createInsertSchema(testSteps).omit({
  id: true,
  createdAt: true,
});

export const insertTestRunSchema = createInsertSchema(testRuns).omit({
  id: true,
  startedAt: true,
  completedAt: true,
  passedSteps: true,
  failedSteps: true,
});

export const insertTestStepResultSchema = createInsertSchema(testStepResults).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertTestSuite = z.infer<typeof insertTestSuiteSchema>;
export type TestSuite = typeof testSuites.$inferSelect;

export type InsertTestStep = z.infer<typeof insertTestStepSchema>;
export type TestStep = typeof testSteps.$inferSelect;

export type InsertTestRun = z.infer<typeof insertTestRunSchema>;
export type TestRun = typeof testRuns.$inferSelect;

export type InsertTestStepResult = z.infer<typeof insertTestStepResultSchema>;
export type TestStepResult = typeof testStepResults.$inferSelect;
