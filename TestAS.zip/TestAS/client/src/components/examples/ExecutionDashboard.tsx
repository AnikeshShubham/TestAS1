import ExecutionDashboard from '../ExecutionDashboard';

export default function ExecutionDashboardExample() {
  //todo: remove mock functionality
  const mockSteps = [
    { id: '1', description: 'Navigate to https://example.com', status: 'passed' as const, duration: 1234 },
    { id: '2', description: 'Click the "Get Started" button', status: 'running' as const },
    { id: '3', description: 'Verify the page title contains "Welcome"', status: 'pending' as const },
    { id: '4', description: 'Fill out the contact form', status: 'pending' as const },
  ];

  return <ExecutionDashboard steps={mockSteps} isRunning={true} />;
}