import { ThemeProvider } from '../ThemeProvider';
import { Button } from '@/components/ui/button';

export default function ThemeProviderExample() {
  return (
    <ThemeProvider>
      <div className="p-4 space-y-2">
        <p>Theme Provider Example - the theme is managed globally</p>
        <Button onClick={() => console.log('Theme provider working')}>
          Test Button
        </Button>
      </div>
    </ThemeProvider>
  );
}