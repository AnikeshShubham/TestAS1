import TestStepEditor from '../TestStepEditor';

export default function TestStepEditorExample() {
  return (
    <TestStepEditor 
      onRunTests={(steps) => console.log('Running tests:', steps)}
      onStepsChange={(steps) => console.log('Steps changed:', steps)}
    />
  );
}