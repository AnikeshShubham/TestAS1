import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { CheckCircle, XCircle, Clock, Play, AlertTriangle } from 'lucide-react';

interface TestStep {
  id: string;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  duration?: number;
  error?: string;
  logs?: string[];
}

interface ExecutionDashboardProps {
  steps?: TestStep[];
  isRunning?: boolean;
}

const getStatusIcon = (status: TestStep['status']) => {
  switch (status) {
    case 'pending':
      return <Clock className="w-4 h-4" />;
    case 'running':
      return <Play className="w-4 h-4 animate-pulse" />;
    case 'passed':
      return <CheckCircle className="w-4 h-4" />;
    case 'failed':
      return <XCircle className="w-4 h-4" />;
    default:
      return <Clock className="w-4 h-4" />;
  }
};

const getStatusColor = (status: TestStep['status']) => {
  switch (status) {
    case 'pending':
      return 'text-muted-foreground';
    case 'running':
      return 'text-yellow-600';
    case 'passed':
      return 'text-green-600';
    case 'failed':
      return 'text-red-600';
    default:
      return 'text-muted-foreground';
  }
};

export default function ExecutionDashboard({ steps = [], isRunning = false }: ExecutionDashboardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [executionLogs, setExecutionLogs] = useState<string[]>([]);

  // Mock execution simulation
  useEffect(() => {
    if (isRunning && steps.length > 0) {
      const interval = setInterval(() => {
        setExecutionLogs(prev => [...prev, `Executing step ${currentStep + 1}...`]);
        
        if (currentStep < steps.length - 1) {
          setCurrentStep(prev => prev + 1);
        } else {
          clearInterval(interval);
        }
      }, 2000);

      return () => clearInterval(interval);
    }
  }, [isRunning, currentStep, steps.length]);

  const completedSteps = steps.filter(step => step.status === 'passed' || step.status === 'failed').length;
  const passedSteps = steps.filter(step => step.status === 'passed').length;
  const failedSteps = steps.filter(step => step.status === 'failed').length;
  const progressPercentage = steps.length > 0 ? (completedSteps / steps.length) * 100 : 0;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Execution Progress
            {isRunning && (
              <Badge variant="outline" className="text-yellow-600">
                <Play className="w-3 h-3 mr-1 animate-pulse" />
                Running
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Progress value={progressPercentage} className="w-full" />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Progress: {completedSteps}/{steps.length} steps</span>
              <div className="flex gap-4">
                <span className="text-green-600">{passedSteps} passed</span>
                <span className="text-red-600">{failedSteps} failed</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Test Steps</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {steps.map((step, index) => (
                <div 
                  key={step.id} 
                  className={`flex items-center gap-3 p-3 rounded-md border hover-elevate ${
                    step.status === 'running' ? 'border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950' : ''
                  }`}
                  data-testid={`step-${step.id}`}
                >
                  <span className={`${getStatusColor(step.status)}`}>
                    {getStatusIcon(step.status)}
                  </span>
                  <span className="text-sm min-w-[2rem] text-muted-foreground">
                    {index + 1}.
                  </span>
                  <span className="font-mono text-sm flex-1">
                    {step.description}
                  </span>
                  <Badge 
                    variant={step.status === 'passed' ? 'default' : 
                            step.status === 'failed' ? 'destructive' : 
                            step.status === 'running' ? 'secondary' : 'outline'}
                    className="text-xs"
                    data-testid={`status-${step.id}`}
                  >
                    {step.status}
                  </Badge>
                  {step.duration && (
                    <span className="text-xs text-muted-foreground">
                      {step.duration}ms
                    </span>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {executionLogs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Execution Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-32">
              <div className="space-y-1">
                {executionLogs.map((log, index) => (
                  <div key={index} className="text-sm font-mono text-muted-foreground">
                    [{new Date().toLocaleTimeString()}] {log}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}