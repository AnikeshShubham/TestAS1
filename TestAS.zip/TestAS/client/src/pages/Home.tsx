import TestAutomationApp from '@/components/TestAutomationApp';

export default function Home() {
  return <TestAutomationApp />;
}