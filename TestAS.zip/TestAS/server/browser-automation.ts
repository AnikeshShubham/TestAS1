import puppeteer, { Browser, Page } from 'puppeteer';
import { TestStepParser } from './test-step-parser';
import { OpenAITestEngine, type EnhancedTestStep } from './openai-test-engine';

export interface BrowserExecutionResult {
  status: 'passed' | 'failed';
  duration: number;
  error?: string;
  logs: string[];
  screenshotPath?: string;
  pageUrl?: string;
}

export class BrowserAutomation {
  private static browser: Browser | null = null;
  private static pages: Map<string, Page> = new Map();

  /**
   * Initialize browser instance
   */
  private static async getBrowser(): Promise<Browser> {
    if (!this.browser) {
      this.browser = await puppeteer.launch({
        headless: false, // Show browser window for visual feedback
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--single-process',
          '--disable-gpu'
        ]
      });
    }
    return this.browser;
  }

  /**
   * Execute a test step with real browser automation
   */
  static async executeTestStep(description: string, stepOrder: number): Promise<BrowserExecutionResult> {
    const startTime = Date.now();
    const logs: string[] = [];
    let page: Page | null = null;

    try {
      logs.push(`🚀 [Step ${stepOrder}] Starting real browser automation: ${description}`);
      
      const browser = await this.getBrowser();
      
      // Check if we have an existing page or need to create one
      const pageKey = 'main';
      if (!this.pages.has(pageKey)) {
        page = await browser.newPage();
        this.pages.set(pageKey, page);
        await page.setViewport({ width: 1280, height: 720 });
        logs.push(`📱 Created new browser page (1280x720)`);
      } else {
        page = this.pages.get(pageKey)!;
        logs.push(`🔄 Using existing browser page`);
      }

      // Parse the test step to understand what action to perform
      const parsedStep = TestStepParser.parseTestStep(description);
      logs.push(`🔍 Parsed action: ${parsedStep.action}`);

      let actionSuccess = false;
      let actionDuration = 0;

      switch (parsedStep.action) {
        case 'navigate':
          actionSuccess = await this.performNavigation(page, parsedStep.url!, logs);
          actionDuration = Date.now() - startTime;
          break;
          
        case 'click':
          actionSuccess = await this.performClick(page, parsedStep.selector!, logs);
          actionDuration = Date.now() - startTime;
          break;
          
        case 'type':
          actionSuccess = await this.performType(page, parsedStep.selector!, parsedStep.text!, logs);
          actionDuration = Date.now() - startTime;
          break;
          
        case 'verify':
          actionSuccess = await this.performVerification(page, parsedStep, logs);
          actionDuration = Date.now() - startTime;
          break;
          
        case 'wait':
          await this.performWait(parsedStep.timeout || 1000, logs);
          actionSuccess = true;
          actionDuration = Date.now() - startTime;
          break;
          
        default:
          logs.push(`⚠️ Unknown action: ${parsedStep.action}`);
          // For unknown actions, try to extract URL and navigate
          const urlMatch = description.match(/(https?:\/\/[^\s]+)/);
          if (urlMatch) {
            logs.push(`🌐 Found URL in description, attempting navigation: ${urlMatch[1]}`);
            actionSuccess = await this.performNavigation(page, urlMatch[1], logs);
          } else {
            actionSuccess = false;
          }
          actionDuration = Date.now() - startTime;
          break;
      }

      const totalDuration = Date.now() - startTime;
      const currentUrl = await page.url();

      if (actionSuccess) {
        logs.push(`✅ Step completed successfully in ${totalDuration}ms`);
        logs.push(`📍 Current page: ${currentUrl}`);
        
        return {
          status: 'passed',
          duration: totalDuration,
          logs,
          pageUrl: currentUrl
        };
      } else {
        logs.push(`❌ Step failed after ${totalDuration}ms`);
        return {
          status: 'failed',
          duration: totalDuration,
          error: `Failed to execute ${parsedStep.action} action`,
          logs,
          pageUrl: currentUrl
        };
      }

    } catch (error) {
      const duration = Date.now() - startTime;
      const errorMsg = error instanceof Error ? error.message : 'Unknown browser automation error';
      logs.push(`💥 Browser automation error: ${errorMsg}`);
      
      let pageUrl: string | undefined = undefined;
      if (page) {
        try {
          pageUrl = await page.url();
        } catch {
          pageUrl = 'unknown';
        }
      }
      
      return {
        status: 'failed',
        duration,
        error: errorMsg,
        logs,
        pageUrl
      };
    }
  }

  /**
   * Perform navigation to a URL
   */
  private static async performNavigation(page: Page, url: string, logs: string[]): Promise<boolean> {
    try {
      // Clean up URL if it doesn't have protocol
      const cleanUrl = url.startsWith('http') ? url : `https://${url}`;
      logs.push(`🌐 Navigating to: ${cleanUrl}`);
      
      await page.goto(cleanUrl, { 
        waitUntil: 'networkidle2',
        timeout: 30000
      });
      
      const title = await page.title();
      logs.push(`📄 Page loaded: "${title}"`);
      logs.push(`🔗 Final URL: ${await page.url()}`);
      
      return true;
    } catch (error) {
      logs.push(`❌ Navigation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  }

  /**
   * Perform click action
   */
  private static async performClick(page: Page, selector: string, logs: string[]): Promise<boolean> {
    try {
      logs.push(`🖱️ Looking for element to click: ${selector}`);
      
      await page.waitForSelector(selector, { timeout: 10000 });
      logs.push(`✅ Element found: ${selector}`);
      
      await page.click(selector);
      logs.push(`👆 Clicked element successfully`);
      
      // Wait for potential navigation or changes
      await new Promise(resolve => setTimeout(resolve, 500));
      
      return true;
    } catch (error) {
      logs.push(`❌ Click failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  }

  /**
   * Perform typing action
   */
  private static async performType(page: Page, selector: string, text: string, logs: string[]): Promise<boolean> {
    try {
      logs.push(`⌨️ Looking for input field: ${selector}`);
      
      await page.waitForSelector(selector, { timeout: 10000 });
      logs.push(`✅ Input field found: ${selector}`);
      
      await page.focus(selector);
      await page.type(selector, text, { delay: 100 });
      logs.push(`📝 Typed: "${text}"`);
      
      return true;
    } catch (error) {
      logs.push(`❌ Typing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  }

  /**
   * Perform verification
   */
  private static async performVerification(page: Page, parsedStep: any, logs: string[]): Promise<boolean> {
    try {
      if (parsedStep.target === 'title') {
        const title = await page.title();
        const contains = title.toLowerCase().includes(parsedStep.value.toLowerCase());
        logs.push(`🔍 Page title: "${title}"`);
        logs.push(`🎯 Looking for: "${parsedStep.value}"`);
        logs.push(contains ? `✅ Title verification passed` : `❌ Title verification failed`);
        return contains;
      } else if (parsedStep.selector) {
        logs.push(`🔍 Looking for element: ${parsedStep.selector}`);
        const element = await page.$(parsedStep.selector);
        if (element) {
          logs.push(`✅ Element found`);
          return true;
        } else {
          logs.push(`❌ Element not found`);
          return false;
        }
      }
      return false;
    } catch (error) {
      logs.push(`❌ Verification failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return false;
    }
  }

  /**
   * Perform wait action
   */
  private static async performWait(timeout: number, logs: string[]): Promise<void> {
    logs.push(`⏰ Waiting for ${timeout}ms`);
    await new Promise(resolve => setTimeout(resolve, timeout));
    logs.push(`✅ Wait completed`);
  }

  /**
   * Take a screenshot of current page
   */
  static async takeScreenshot(testRunId: string): Promise<string | null> {
    try {
      const page = this.pages.get('main');
      if (!page) return null;

      const screenshotPath = `screenshots/${testRunId}-${Date.now()}.png` as const;
      await page.screenshot({ path: screenshotPath, fullPage: true });
      return screenshotPath;
    } catch (error) {
      console.error('Screenshot failed:', error);
      return null;
    }
  }

  /**
   * Close browser and cleanup
   */
  static async cleanup(): Promise<void> {
    try {
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
        this.pages.clear();
        console.log('🧹 Browser cleanup completed');
      }
    } catch (error) {
      console.error('Browser cleanup error:', error);
    }
  }

  /**
   * Get current page URL
   */
  static async getCurrentUrl(): Promise<string | null> {
    try {
      const page = this.pages.get('main');
      return page ? await page.url() : null;
    } catch (error) {
      return null;
    }
  }
}