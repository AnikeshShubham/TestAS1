/**
 * Test Step Parser - Converts human-readable test steps into executable automation commands
 */

export interface ParsedTestStep {
  action: 'navigate' | 'click' | 'type' | 'verify' | 'wait' | 'scroll' | 'select' | 'check' | 'uncheck' | 'unknown';
  selector?: string;
  locatorType?: 'css' | 'xpath';
  text?: string;
  url?: string;
  value?: string;
  condition?: 'contains' | 'equals' | 'exists' | 'visible' | 'enabled' | 'disabled';
  target?: 'title' | 'text' | 'element' | 'url' | 'attribute';
  attribute?: string;
  timeout?: number;
  originalStep: string;
}

export class TestStepParser {
  private static readonly NAVIGATION_PATTERNS = [
    /^(?:navigate|go) to (.+)$/i,
    /^(?:visit|open) (.+)$/i,
    /^(?:load|access) (.+)$/i,
  ];

  private static readonly CLICK_PATTERNS = [
    /^click (?:the )?(.+?)(?:\s+button|\s+link|\s+element)?$/i,
    /^(?:tap|press) (?:the )?(.+?)(?:\s+button|\s+link|\s+element)?$/i,
    /^select (?:the )?(.+?)(?:\s+option|\s+item|\s+button)$/i,
  ];

  private static readonly SELECT_PATTERNS = [
    /^select ['"](.+?)['"] from (?:the )?(.+?)(?:\s+dropdown|\s+select|\s+list)?$/i,
    /^choose ['"](.+?)['"] from (?:the )?(.+?)$/i,
  ];

  private static readonly CHECKBOX_PATTERNS = [
    /^check (?:the )?(.+?)(?:\s+checkbox)$/i,
    /^uncheck (?:the )?(.+?)(?:\s+checkbox)?$/i,
    /^(?:check|uncheck) (?:the )?(.+?)(?:\s+box)$/i,
  ];

  private static readonly TYPE_PATTERNS = [
    /^(?:type|enter|input) ['"](.+?)['"] (?:in|into) (?:the )?(.+?)(?:\s+field|\s+input)?$/i,
    /^(?:fill|populate) (?:the )?(.+?)(?:\s+field|\s+input)? with ['"](.+?)['"]$/i,
  ];

  private static readonly VERIFY_PATTERNS = [
    /^(?:verify|check|assert) (?:that )?(?:the )?(.+?) (?:contains|has) ['"](.+?)['"]$/i,
    /^(?:verify|check|assert) (?:that )?(?:the )?(.+?) (?:equals|is) ['"](.+?)['"]$/i,
    /^(?:verify|check|assert) (?:that )?(?:the )?(.+?) (?:exists|is (?:visible|present))$/i,
    /^(?:verify|check|assert) (?:that )?(?:the )?(.+?) (?:is (?:enabled|clickable))$/i,
  ];

  private static readonly WAIT_PATTERNS = [
    /^wait (?:for )?(\d+) (?:seconds?|ms|milliseconds?)$/i,
    /^wait (?:for|until) (?:the )?(.+?) (?:appears|is visible|exists)$/i,
    /^pause (?:for )?(\d+) (?:seconds?|ms|milliseconds?)$/i,
  ];

  private static readonly SCROLL_PATTERNS = [
    /^scroll (?:to )?(?:the )?(.+)$/i,
    /^scroll (up|down|left|right)$/i,
  ];

  /**
   * Parse a human-readable test step into an executable command
   */
  static parseTestStep(step: string): ParsedTestStep {
    const trimmedStep = step.trim();

    // Try navigation patterns
    for (const pattern of this.NAVIGATION_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        return {
          action: 'navigate',
          url: match[1].trim(),
          originalStep: trimmedStep,
        };
      }
    }

    // Try select patterns (dropdown)
    for (const pattern of this.SELECT_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const optionValue = match[1].trim();
        const dropdownDescription = match[2].trim();
        const selectorResult = this.generateSelector(dropdownDescription);
        return {
          action: 'select',
          selector: selectorResult.selector,
          locatorType: selectorResult.locatorType,
          value: optionValue,
          originalStep: trimmedStep,
        };
      }
    }

    // Try checkbox patterns
    for (const pattern of this.CHECKBOX_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const checkboxDescription = match[1].trim();
        const selectorResult = this.generateSelector(checkboxDescription);
        const action = trimmedStep.toLowerCase().includes('uncheck') ? 'uncheck' : 'check';
        return {
          action: action,
          selector: selectorResult.selector,
          locatorType: selectorResult.locatorType,
          originalStep: trimmedStep,
        };
      }
    }

    // Try click patterns
    for (const pattern of this.CLICK_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const elementDescription = match[1].trim();
        const selectorResult = this.generateSelector(elementDescription);
        return {
          action: 'click',
          selector: selectorResult.selector,
          locatorType: selectorResult.locatorType,
          originalStep: trimmedStep,
        };
      }
    }

    // Try type patterns
    for (const pattern of this.TYPE_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        // Handle different capture group orders
        let text: string, fieldDescription: string;
        
        if (trimmedStep.toLowerCase().includes('fill') || trimmedStep.toLowerCase().includes('populate')) {
          // Pattern: "fill field with text"
          fieldDescription = match[1].trim();
          text = match[2].trim();
        } else {
          // Pattern: "type text into field"
          text = match[1].trim();
          fieldDescription = match[2].trim();
        }

        const selectorResult = this.generateSelector(fieldDescription);
        return {
          action: 'type',
          selector: selectorResult.selector,
          locatorType: selectorResult.locatorType,
          text: text,
          originalStep: trimmedStep,
        };
      }
    }

    // Try verify patterns
    for (const pattern of this.VERIFY_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const elementDescription = match[1].trim().toLowerCase();
        
        // Determine verification target and condition
        let target: ParsedTestStep['target'] = 'text';
        let condition: ParsedTestStep['condition'] = 'contains';
        let value: string | undefined;

        if (elementDescription.includes('title') || elementDescription.includes('page title')) {
          target = 'title';
        } else if (elementDescription.includes('url') || elementDescription.includes('address')) {
          target = 'url';
        }

        // Extract condition from the original step text
        if (trimmedStep.toLowerCase().includes('contains') || trimmedStep.toLowerCase().includes('has')) {
          condition = 'contains';
          value = match[2]?.trim();
        } else if (trimmedStep.toLowerCase().includes('equals') || (trimmedStep.toLowerCase().includes('is') && !trimmedStep.toLowerCase().includes('exists') && !trimmedStep.toLowerCase().includes('visible') && !trimmedStep.toLowerCase().includes('enabled'))) {
          condition = 'equals';
          value = match[2]?.trim();
        } else if (trimmedStep.toLowerCase().includes('exists') || trimmedStep.toLowerCase().includes('visible') || trimmedStep.toLowerCase().includes('present')) {
          condition = 'exists';
        } else if (trimmedStep.toLowerCase().includes('enabled') || trimmedStep.toLowerCase().includes('clickable')) {
          condition = 'enabled';
        }

        let selectorResult = target === 'text' ? this.generateSelector(elementDescription) : undefined;
        return {
          action: 'verify',
          target: target,
          condition: condition,
          value: value,
          selector: selectorResult?.selector,
          locatorType: selectorResult?.locatorType,
          originalStep: trimmedStep,
        };
      }
    }

    // Try wait patterns
    for (const pattern of this.WAIT_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const isTimeWait = /\d+/.test(match[1]);
        
        if (isTimeWait) {
          let timeout = parseInt(match[1]);
          // Convert seconds to milliseconds if needed
          if (trimmedStep.includes('second')) {
            timeout *= 1000;
          }
          
          return {
            action: 'wait',
            timeout: timeout,
            originalStep: trimmedStep,
          };
        } else {
          // Wait for element
          const selectorResult = this.generateSelector(match[1].trim());
          return {
            action: 'wait',
            selector: selectorResult.selector,
            locatorType: selectorResult.locatorType,
            condition: 'visible',
            timeout: 5000,
            originalStep: trimmedStep,
          };
        }
      }
    }

    // Try scroll patterns
    for (const pattern of this.SCROLL_PATTERNS) {
      const match = trimmedStep.match(pattern);
      if (match) {
        const target = match[1].trim().toLowerCase();
        
        if (['up', 'down', 'left', 'right'].includes(target)) {
          return {
            action: 'scroll',
            value: target,
            originalStep: trimmedStep,
          };
        } else {
          const selectorResult = this.generateSelector(target);
          return {
            action: 'scroll',
            selector: selectorResult.selector,
            locatorType: selectorResult.locatorType,
            originalStep: trimmedStep,
          };
        }
      }
    }

    // If no pattern matches, return unknown action
    return {
      action: 'unknown',
      originalStep: trimmedStep,
    };
  }

  /**
   * Generate a Puppeteer-compatible selector from a human description
   */
  private static generateSelector(description: string): { selector: string; locatorType: 'css' | 'xpath' } {
    const desc = description.toLowerCase().trim();

    // Check if it's already a valid CSS selector or XPath
    if (description.startsWith('#') || description.startsWith('.') || description.startsWith('[') || description.includes('data-test')) {
      return { selector: description, locatorType: 'css' };
    }
    if (description.startsWith('//') || description.startsWith('/')) {
      return { selector: description, locatorType: 'xpath' };
    }

    // Handle specific input types with CSS selectors
    if (desc.includes('email')) {
      return { selector: 'input[type="email"], input[name*="email"], input[id*="email"]', locatorType: 'css' };
    }
    if (desc.includes('password')) {
      return { selector: 'input[type="password"], input[name*="password"], input[id*="password"]', locatorType: 'css' };
    }
    if (desc.includes('search')) {
      return { selector: 'input[type="search"], input[name*="search"], input[id*="search"], input[placeholder*="search"]', locatorType: 'css' };
    }

    // Handle buttons with XPath for text content
    if (desc.includes('button') || desc.includes('btn')) {
      const buttonText = desc.replace(/button|btn/g, '').trim();
      if (buttonText) {
        return { 
          selector: `//button[contains(normalize-space(.), "${buttonText}")] | //input[@type="button" and contains(@value, "${buttonText}")] | //input[@type="submit" and contains(@value, "${buttonText}")] | //*[@role="button" and contains(normalize-space(.), "${buttonText}")]`,
          locatorType: 'xpath'
        };
      }
      return { selector: 'button, input[type="button"], input[type="submit"], [role="button"]', locatorType: 'css' };
    }

    // Handle links with XPath for text content  
    if (desc.includes('link')) {
      const linkText = desc.replace(/link/g, '').trim();
      if (linkText) {
        return { 
          selector: `//a[contains(normalize-space(.), "${linkText}")] | //*[@href and contains(normalize-space(.), "${linkText}")]`,
          locatorType: 'xpath'
        };
      }
      return { selector: 'a, [href]', locatorType: 'css' };
    }

    // Handle form fields
    if (desc.includes('field') || desc.includes('input')) {
      const fieldName = desc.replace(/field|input/g, '').trim();
      if (fieldName) {
        return { 
          selector: `input[name*="${fieldName}"], input[id*="${fieldName}"], input[placeholder*="${fieldName}"], textarea[name*="${fieldName}"], textarea[id*="${fieldName}"], label:contains("${fieldName}") + input, label:contains("${fieldName}") + textarea`,
          locatorType: 'css'
        };
      }
      return { selector: 'input, textarea, select', locatorType: 'css' };
    }

    // Handle checkboxes and radio buttons
    if (desc.includes('checkbox')) {
      const checkboxName = desc.replace(/checkbox/g, '').trim();
      if (checkboxName) {
        return { 
          selector: `//input[@type="checkbox" and (contains(@name, "${checkboxName}") or contains(@id, "${checkboxName}") or following-sibling::text()[contains(., "${checkboxName}")] or preceding-sibling::text()[contains(., "${checkboxName}")])]`,
          locatorType: 'xpath'
        };
      }
      return { selector: 'input[type="checkbox"]', locatorType: 'css' };
    }
    if (desc.includes('radio')) {
      return { selector: 'input[type="radio"]', locatorType: 'css' };
    }

    // Handle dropdown/select
    if (desc.includes('dropdown') || desc.includes('select')) {
      return { selector: 'select, [role="combobox"], [role="listbox"]', locatorType: 'css' };
    }

    // Generic approach - use XPath for text-based matching
    const cleanDesc = desc.replace(/^the\s+/i, '');
    
    // Try CSS first for attribute-based matching
    const hasAttributes = cleanDesc.match(/[a-z]+/);
    if (hasAttributes) {
      const attributeSelector = `[id*="${cleanDesc}"], [class*="${cleanDesc}"], [name*="${cleanDesc}"], [data-testid*="${cleanDesc}"]`;
      
      // Also create XPath for text content as fallback
      const textXPath = `//*[contains(normalize-space(.), "${cleanDesc}") and (self::button or self::a or self::span or self::div or self::p or self::h1 or self::h2 or self::h3 or self::h4 or self::h5 or self::h6 or self::label)]`;
      
      // Return XPath that tries both approaches
      return {
        selector: textXPath,
        locatorType: 'xpath'
      };
    }

    // Fallback to generic XPath
    return {
      selector: `//*[contains(normalize-space(.), "${cleanDesc}")]`,
      locatorType: 'xpath'
    };
  }

  /**
   * Batch parse multiple test steps
   */
  static parseTestSteps(steps: string[]): ParsedTestStep[] {
    return steps.map(step => this.parseTestStep(step));
  }

  /**
   * Validate if a test step can be parsed
   */
  static canParse(step: string): boolean {
    const parsed = this.parseTestStep(step);
    return parsed.action !== 'unknown';
  }

  /**
   * Get suggested improvements for unparseable steps
   */
  static getSuggestion(step: string): string {
    const suggestions = [
      "Try using patterns like:",
      "• Navigate to [URL]",
      "• Click the [button/link name]",
      "• Type '[text]' in the [field name]",
      "• Verify the [element] contains '[expected text]'",
      "• Wait for 3 seconds",
      "• Wait for the [element] to appear"
    ];
    
    return suggestions.join('\n');
  }
}