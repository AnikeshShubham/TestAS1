import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface EnhancedTestStep {
  stepNumber: number;
  action: 'navigate' | 'click' | 'type' | 'verify' | 'wait' | 'scroll' | 'select' | 'check' | 'uncheck';
  description: string;
  selector?: string;
  text?: string;
  url?: string;
  value?: string;
  timeout?: number;
  expectedOutcome: string;
  tips: string[];
}

export interface TestExecutionPlan {
  totalSteps: number;
  steps: EnhancedTestStep[];
  estimatedDuration: number;
  complexity: 'simple' | 'moderate' | 'complex';
}

export class OpenAITestEngine {
  /**
   * Parse and enhance test steps using OpenAI
   */
  static async parseTestSteps(testDescription: string): Promise<TestExecutionPlan> {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("OpenAI API key not configured");
    }

    const prompt = `You are an expert test automation engineer. Parse the following test description into detailed, executable test steps.

Test Description:
${testDescription}

Please respond with a JSON object in this exact format:
{
  "totalSteps": number,
  "estimatedDuration": number (in milliseconds),
  "complexity": "simple" | "moderate" | "complex",
  "steps": [
    {
      "stepNumber": number,
      "action": "navigate" | "click" | "type" | "verify" | "wait" | "scroll" | "select" | "check" | "uncheck",
      "description": "Clear description of what this step does",
      "selector": "CSS selector or XPath for the element (if applicable)",
      "text": "Text to type or verify (if applicable)",
      "url": "URL to navigate to (if applicable)", 
      "value": "Value to select or verify (if applicable)",
      "timeout": number (in milliseconds, if applicable),
      "expectedOutcome": "What should happen after this step",
      "tips": ["Array of helpful tips for executing this step"]
    }
  ]
}

Guidelines:
- Break down complex multi-step descriptions into individual atomic steps
- For navigation steps, include full URLs
- For click steps, provide the best CSS selector or descriptive element identifier
- For typing steps, specify both the text and target element
- For verification steps, clearly state what to verify and expected result
- Include realistic timeouts for wait steps (1000-5000ms typically)
- Add helpful tips for each step that would help with debugging
- Estimate realistic execution times based on step complexity`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      return result as TestExecutionPlan;
    } catch (error) {
      console.error('OpenAI parsing error:', error);
      // Fallback to basic parsing
      return this.fallbackParse(testDescription);
    }
  }

  /**
   * Execute a test step with enhanced logging and realistic simulation
   */
  static async executeTestStep(step: EnhancedTestStep): Promise<{
    status: 'passed' | 'failed';
    duration: number;
    error?: string;
    logs: string[];
    details: string[];
  }> {
    const startTime = Date.now();
    const logs: string[] = [];
    const details: string[] = [];

    try {
      logs.push(`[Step ${step.stepNumber}] Starting: ${step.description}`);
      
      // Add OpenAI-enhanced execution details
      details.push(`Action Type: ${step.action}`);
      if (step.selector) details.push(`Target Element: ${step.selector}`);
      if (step.url) details.push(`URL: ${step.url}`);
      if (step.text) details.push(`Text: ${step.text}`);
      
      // Add helpful tips to logs
      step.tips.forEach(tip => logs.push(`💡 Tip: ${tip}`));

      // Simulate realistic execution based on action type
      let executionTime = 1000;
      let successRate = 0.85; // Base success rate

      switch (step.action) {
        case 'navigate':
          executionTime = Math.random() * 1000 + 1500; // 1.5-2.5s
          successRate = 0.95;
          logs.push(`🌐 Navigating to: ${step.url}`);
          logs.push(`⏳ Waiting for page to load...`);
          break;
          
        case 'click':
          executionTime = Math.random() * 300 + 200; // 200-500ms
          successRate = 0.90;
          logs.push(`🖱️ Locating element: ${step.selector || step.description}`);
          logs.push(`✋ Clicking element...`);
          break;
          
        case 'type':
          executionTime = (step.text?.length || 10) * 50 + Math.random() * 200; // Typing speed
          successRate = 0.92;
          logs.push(`⌨️ Focusing on input field: ${step.selector}`);
          logs.push(`📝 Typing: "${step.text}"`);
          break;
          
        case 'verify':
          executionTime = Math.random() * 500 + 300; // 300-800ms
          successRate = 0.85;
          logs.push(`🔍 Searching for: ${step.value || step.text}`);
          logs.push(`✅ Verifying element presence and content...`);
          break;
          
        case 'wait':
          executionTime = step.timeout || 1000;
          successRate = 0.98;
          logs.push(`⏰ Waiting for ${executionTime}ms`);
          break;
          
        case 'scroll':
          executionTime = Math.random() * 200 + 100;
          successRate = 0.95;
          logs.push(`📜 Scrolling to element: ${step.selector}`);
          break;
          
        default:
          logs.push(`🔧 Executing custom action: ${step.description}`);
          break;
      }

      // Simulate the actual execution time
      await new Promise(resolve => setTimeout(resolve, executionTime));
      
      // Determine success/failure with enhanced logic
      const success = Math.random() < successRate;
      const duration = Date.now() - startTime;
      
      if (success) {
        logs.push(`✅ Step completed successfully in ${duration}ms`);
        logs.push(`🎯 Expected outcome achieved: ${step.expectedOutcome}`);
        
        return {
          status: 'passed',
          duration,
          logs,
          details
        };
      } else {
        const errorMessages = {
          navigate: 'Page failed to load or took too long',
          click: 'Element not found or not clickable',
          type: 'Input field not accessible or validation failed',
          verify: 'Expected content not found or assertion failed',
          wait: 'Timeout exceeded waiting for condition',
          scroll: 'Element not found or scroll failed',
          select: 'Dropdown option not found or not selectable',
          check: 'Checkbox not found or already checked',
          uncheck: 'Checkbox not found or already unchecked'
        };
        
        const error = errorMessages[step.action] || 'Unknown error occurred';
        logs.push(`❌ Step failed: ${error}`);
        logs.push(`🔍 Troubleshooting: ${step.tips.join(', ')}`);
        
        return {
          status: 'failed',
          duration,
          error,
          logs,
          details
        };
      }
    } catch (error) {
      const duration = Date.now() - startTime;
      logs.push(`💥 Unexpected error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      
      return {
        status: 'failed',
        duration,
        error: error instanceof Error ? error.message : 'Execution failed',
        logs,
        details
      };
    }
  }

  /**
   * Fallback parser when OpenAI is not available
   */
  private static fallbackParse(description: string): TestExecutionPlan {
    const lines = description.split('\n').filter(line => line.trim());
    const steps: EnhancedTestStep[] = [];
    
    lines.forEach((line, index) => {
      const cleanLine = line.replace(/^\d+\.\s*/, '').trim();
      let action: EnhancedTestStep['action'] = 'verify';
      let url: string | undefined;
      let text: string | undefined;
      let selector: string | undefined;
      
      if (cleanLine.toLowerCase().includes('navigate') || cleanLine.toLowerCase().includes('go to')) {
        action = 'navigate';
        const urlMatch = cleanLine.match(/(https?:\/\/[^\s]+)/);
        url = urlMatch ? urlMatch[1] : undefined;
      } else if (cleanLine.toLowerCase().includes('click')) {
        action = 'click';
        selector = 'button, a, [role="button"]';
      } else if (cleanLine.toLowerCase().includes('type') || cleanLine.toLowerCase().includes('enter')) {
        action = 'type';
        selector = 'input, textarea';
        const textMatch = cleanLine.match(/["']([^"']+)["']/);
        text = textMatch ? textMatch[1] : cleanLine.split(' ').pop();
      }
      
      steps.push({
        stepNumber: index + 1,
        action,
        description: cleanLine,
        selector,
        text,
        url,
        expectedOutcome: `Step ${index + 1} should complete successfully`,
        tips: [`Ensure the page is fully loaded before executing this step`]
      });
    });

    return {
      totalSteps: steps.length,
      steps,
      estimatedDuration: steps.length * 2000,
      complexity: steps.length > 5 ? 'complex' : steps.length > 2 ? 'moderate' : 'simple'
    };
  }
}