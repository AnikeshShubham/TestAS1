/**
 * Tests for TestStepParserV2 - Focus on Puppeteer compatibility
 */

import { TestStepParser } from './test-step-parser';

// Simple test framework
function test(name: string, fn: () => void) {
  try {
    fn();
    console.log(`✓ ${name}`);
  } catch (error) {
    console.error(`✗ ${name}: ${error}`);
  }
}

function assertEquals(actual: any, expected: any, message?: string) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(message || `Expected ${JSON.stringify(expected)}, but got ${JSON.stringify(actual)}`);
  }
}

function assertContains(actual: string, expected: string, message?: string) {
  if (!actual.includes(expected)) {
    throw new Error(message || `Expected "${actual}" to contain "${expected}"`);
  }
}

console.log('\n🧪 Running TestStepParserV2 Tests...\n');

// Test Navigation
test('parses navigation steps', () => {
  const step = "Navigate to https://example.com";
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'navigate');
  assertEquals(parsed.url, 'https://example.com');
});

test('parses visit steps', () => {
  const step = "Visit https://google.com";
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'navigate');
  assertEquals(parsed.url, 'https://google.com');
});

// Test Type Patterns
test('parses type steps', () => {
  const step = 'Type "john@example.com" in the email field';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'type');
  assertEquals(parsed.text, 'john@example.com');
  assertEquals(parsed.locatorType, 'css');
  assertContains(parsed.selector || '', 'email');
});

test('parses fill steps', () => {
  const step = 'Fill the username field with "testuser"';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'type');
  assertEquals(parsed.text, 'testuser');
  assertEquals(parsed.locatorType, 'css');
  assertContains(parsed.selector || '', 'username');
});

// Test Click Patterns
test('parses click steps with XPath', () => {
  const step = "Click the login button";
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'click');
  assertEquals(parsed.locatorType, 'xpath');
  assertContains(parsed.selector || '', 'translate');
  assertContains(parsed.selector || '', 'login');
});

test('parses CSS selector pass-through', () => {
  const step = "Click #submit-btn";
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'click');
  assertEquals(parsed.locatorType, 'css');
  assertEquals(parsed.selector, '#submit-btn');
});

// Test Verify Patterns
test('parses verify title steps', () => {
  const step = 'Verify the title contains "Welcome"';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'verify');
  assertEquals(parsed.target, 'title');
  assertEquals(parsed.condition, 'contains');
  assertEquals(parsed.value, 'Welcome');
});

test('parses verify text steps', () => {
  const step = 'Verify the heading contains "Dashboard"';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'verify');
  assertEquals(parsed.target, 'text');
  assertEquals(parsed.condition, 'contains');
  assertEquals(parsed.value, 'Dashboard');
  assertEquals(parsed.locatorType, 'xpath');
});

// Test Wait Patterns
test('parses wait seconds', () => {
  const step = 'Wait for 3 seconds';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'wait');
  assertEquals(parsed.timeout, 3000);
});

test('parses wait milliseconds', () => {
  const step = 'Wait for 500 ms';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'wait');
  assertEquals(parsed.timeout, 500);
});

// Test Unknown Patterns
test('handles unknown patterns', () => {
  const step = 'Do something completely random';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'unknown');
});

// Test XPath Escaping
test('escapes XPath text properly', () => {
  const step = 'Click the "Save & Exit" button';
  const parsed = TestStepParser.parseTestStep(step);
  
  assertEquals(parsed.action, 'click');
  assertEquals(parsed.locatorType, 'xpath');
  // Should not cause XPath syntax errors
  assertContains(parsed.selector || '', 'save');
});

// Test Batch Parsing
test('parses multiple steps', () => {
  const steps = [
    'Navigate to https://example.com',
    'Type "test@example.com" in the email field',
    'Click the submit button'
  ];
  
  const parsed = TestStepParser.parseTestSteps(steps);
  
  assertEquals(parsed.length, 3);
  assertEquals(parsed[0].action, 'navigate');
  assertEquals(parsed[1].action, 'type');
  assertEquals(parsed[2].action, 'click');
});

console.log('\nParser tests completed.\n');