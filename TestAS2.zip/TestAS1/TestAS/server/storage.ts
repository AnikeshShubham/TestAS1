import { 
  type TestSuite, 
  type InsertTestSuite,
  type TestStep,
  type InsertTestStep,
  type TestRun,
  type InsertTestRun,
  type TestStepResult,
  type InsertTestStepResult
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Test Suite operations
  createTestSuite(testSuite: InsertTestSuite): Promise<TestSuite>;
  getTestSuite(id: string): Promise<TestSuite | undefined>;
  getAllTestSuites(): Promise<TestSuite[]>;
  updateTestSuite(id: string, testSuite: Partial<InsertTestSuite>): Promise<TestSuite | undefined>;
  deleteTestSuite(id: string): Promise<boolean>;

  // Test Step operations
  createTestStep(testStep: InsertTestStep): Promise<TestStep>;
  getTestStepsByTestSuite(testSuiteId: string): Promise<TestStep[]>;
  updateTestStep(id: string, testStep: Partial<InsertTestStep>): Promise<TestStep | undefined>;
  deleteTestStep(id: string): Promise<boolean>;

  // Test Run operations
  createTestRun(testRun: InsertTestRun): Promise<TestRun>;
  getTestRun(id: string): Promise<TestRun | undefined>;
  getTestRunsByTestSuite(testSuiteId: string): Promise<TestRun[]>;
  updateTestRun(id: string, testRun: Partial<TestRun>): Promise<TestRun | undefined>;

  // Test Step Result operations
  createTestStepResult(result: InsertTestStepResult): Promise<TestStepResult>;
  getTestStepResultsByTestRun(testRunId: string): Promise<TestStepResult[]>;
  updateTestStepResult(id: string, result: Partial<TestStepResult>): Promise<TestStepResult | undefined>;
}

export class MemStorage implements IStorage {
  private testSuites: Map<string, TestSuite> = new Map();
  private testSteps: Map<string, TestStep> = new Map();
  private testRuns: Map<string, TestRun> = new Map();
  private testStepResults: Map<string, TestStepResult> = new Map();

  // Test Suite operations
  async createTestSuite(insertTestSuite: InsertTestSuite): Promise<TestSuite> {
    const id = randomUUID();
    const testSuite: TestSuite = { 
      ...insertTestSuite,
      description: insertTestSuite.description || null,
      id,
      createdAt: new Date()
    };
    this.testSuites.set(id, testSuite);
    return testSuite;
  }

  async getTestSuite(id: string): Promise<TestSuite | undefined> {
    return this.testSuites.get(id);
  }

  async getAllTestSuites(): Promise<TestSuite[]> {
    return Array.from(this.testSuites.values());
  }

  async updateTestSuite(id: string, updates: Partial<InsertTestSuite>): Promise<TestSuite | undefined> {
    const existing = this.testSuites.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.testSuites.set(id, updated);
    return updated;
  }

  async deleteTestSuite(id: string): Promise<boolean> {
    return this.testSuites.delete(id);
  }

  // Test Step operations
  async createTestStep(insertTestStep: InsertTestStep): Promise<TestStep> {
    const id = randomUUID();
    const testStep: TestStep = { 
      ...insertTestStep,
      testSuiteId: insertTestStep.testSuiteId || null,
      id,
      createdAt: new Date()
    };
    this.testSteps.set(id, testStep);
    return testStep;
  }

  async getTestStepsByTestSuite(testSuiteId: string): Promise<TestStep[]> {
    return Array.from(this.testSteps.values())
      .filter(step => step.testSuiteId === testSuiteId)
      .sort((a, b) => a.stepOrder - b.stepOrder);
  }

  async updateTestStep(id: string, updates: Partial<InsertTestStep>): Promise<TestStep | undefined> {
    const existing = this.testSteps.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.testSteps.set(id, updated);
    return updated;
  }

  async deleteTestStep(id: string): Promise<boolean> {
    return this.testSteps.delete(id);
  }

  // Test Run operations
  async createTestRun(insertTestRun: InsertTestRun): Promise<TestRun> {
    const id = randomUUID();
    const testRun: TestRun = { 
      ...insertTestRun,
      status: insertTestRun.status || 'pending',
      testSuiteId: insertTestRun.testSuiteId || null,
      totalSteps: insertTestRun.totalSteps || null,
      id,
      startedAt: new Date(),
      completedAt: null,
      passedSteps: 0,
      failedSteps: 0
    };
    this.testRuns.set(id, testRun);
    return testRun;
  }

  async getTestRun(id: string): Promise<TestRun | undefined> {
    return this.testRuns.get(id);
  }

  async getTestRunsByTestSuite(testSuiteId: string): Promise<TestRun[]> {
    return Array.from(this.testRuns.values())
      .filter(run => run.testSuiteId === testSuiteId)
      .sort((a, b) => (b.startedAt?.getTime() || 0) - (a.startedAt?.getTime() || 0));
  }

  async updateTestRun(id: string, updates: Partial<TestRun>): Promise<TestRun | undefined> {
    const existing = this.testRuns.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.testRuns.set(id, updated);
    return updated;
  }

  // Test Step Result operations
  async createTestStepResult(insertResult: InsertTestStepResult): Promise<TestStepResult> {
    const id = randomUUID();
    const result: TestStepResult = { 
      ...insertResult,
      testRunId: insertResult.testRunId || null,
      duration: insertResult.duration || null,
      errorMessage: insertResult.errorMessage || null,
      logs: insertResult.logs || null,
      screenshotPath: insertResult.screenshotPath || null,
      id,
      createdAt: new Date()
    };
    this.testStepResults.set(id, result);
    return result;
  }

  async getTestStepResultsByTestRun(testRunId: string): Promise<TestStepResult[]> {
    return Array.from(this.testStepResults.values())
      .filter(result => result.testRunId === testRunId)
      .sort((a, b) => a.stepOrder - b.stepOrder);
  }

  async updateTestStepResult(id: string, updates: Partial<TestStepResult>): Promise<TestStepResult | undefined> {
    const existing = this.testStepResults.get(id);
    if (!existing) return undefined;
    
    const updated = { ...existing, ...updates };
    this.testStepResults.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
