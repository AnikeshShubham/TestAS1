/**
 * Test Step Parser V2 - Truly Puppeteer-compatible with proper selector generation
 */

export interface ParsedTestStep {
  action: 'navigate' | 'click' | 'type' | 'verify' | 'wait' | 'scroll' | 'select' | 'check' | 'uncheck' | 'unknown';
  selector?: string;
  locatorType?: 'css' | 'xpath';
  text?: string;
  url?: string;
  value?: string;
  condition?: 'contains' | 'equals' | 'exists' | 'visible' | 'enabled' | 'disabled';
  target?: 'title' | 'text' | 'element' | 'url' | 'attribute';
  attribute?: string;
  timeout?: number;
  originalStep: string;
}

export class TestStepParser {
  /**
   * Parse a human-readable test step into an executable command
   */
  static parseTestStep(step: string): ParsedTestStep {
    const trimmedStep = step.trim();
    const lowerStep = trimmedStep.toLowerCase();

    // Navigation patterns
    if (lowerStep.startsWith('navigate to ') || lowerStep.startsWith('go to ')) {
      const url = trimmedStep.split(' ').slice(2).join(' ').trim();
      return {
        action: 'navigate',
        url: url,
        originalStep: trimmedStep,
      };
    }
    
    if (lowerStep.startsWith('visit ') || lowerStep.startsWith('open ')) {
      const url = trimmedStep.split(' ').slice(1).join(' ').trim();
      return {
        action: 'navigate',
        url: url,
        originalStep: trimmedStep,
      };
    }

    // Type patterns - look for quoted text and field descriptions
    const typeMatch = trimmedStep.match(/(?:type|enter|input)\s+["'](.+?)["']\s+(?:in|into)\s+(?:the\s+)?(.+?)(?:\s+field|\s+input)?$/i) ||
                     trimmedStep.match(/(?:fill|populate)\s+(?:the\s+)?(.+?)(?:\s+field|\s+input)?\s+with\s+["'](.+?)["']$/i);
    
    if (typeMatch) {
      let text: string, fieldDesc: string;
      if (lowerStep.includes('fill') || lowerStep.includes('populate')) {
        fieldDesc = typeMatch[1].trim();
        text = typeMatch[2].trim();
      } else {
        text = typeMatch[1].trim();
        fieldDesc = typeMatch[2].trim();
      }

      const selector = this.generateFieldSelector(fieldDesc);
      return {
        action: 'type',
        selector: selector.selector,
        locatorType: selector.locatorType,
        text: text,
        originalStep: trimmedStep,
      };
    }

    // Click patterns
    const clickMatch = trimmedStep.match(/^(?:click|tap|press)\s+(?:the\s+)?(.+?)(?:\s+button|\s+link|\s+element)?$/i);
    if (clickMatch) {
      const elementDesc = clickMatch[1].trim();
      const selector = this.generateClickSelector(elementDesc);
      return {
        action: 'click',
        selector: selector.selector,
        locatorType: selector.locatorType,
        originalStep: trimmedStep,
      };
    }

    // Verify patterns
    if (lowerStep.includes('verify') || lowerStep.includes('check') || lowerStep.includes('assert')) {
      if (lowerStep.includes('title')) {
        const titleMatch = trimmedStep.match(/(?:verify|check|assert).*?title.*?(?:contains|has)\s+["'](.+?)["']/i);
        if (titleMatch) {
          return {
            action: 'verify',
            target: 'title',
            condition: 'contains',
            value: titleMatch[1],
            originalStep: trimmedStep,
          };
        }
      }
      
      // Generic element verification
      const verifyMatch = trimmedStep.match(/(?:verify|check|assert).*?(?:the\s+)?(.+?)\s+(?:contains|has)\s+["'](.+?)["']/i);
      if (verifyMatch) {
        const elementDesc = verifyMatch[1].trim();
        const expectedText = verifyMatch[2].trim();
        const selector = this.generateTextSelector(elementDesc, expectedText);
        
        return {
          action: 'verify',
          target: 'text',
          condition: 'contains',
          value: expectedText,
          selector: selector.selector,
          locatorType: selector.locatorType,
          originalStep: trimmedStep,
        };
      }
    }

    // Wait patterns
    const waitTimeMatch = trimmedStep.match(/wait\s+(?:for\s+)?(\d+)\s+(seconds?|ms|milliseconds?)/i);
    if (waitTimeMatch) {
      let timeout = parseInt(waitTimeMatch[1]);
      if (waitTimeMatch[2].toLowerCase().includes('second')) {
        timeout *= 1000;
      }
      return {
        action: 'wait',
        timeout: timeout,
        originalStep: trimmedStep,
      };
    }

    // If no pattern matches, return unknown
    return {
      action: 'unknown',
      originalStep: trimmedStep,
    };
  }

  /**
   * Generate selector for form fields (inputs, textareas)
   */
  private static generateFieldSelector(description: string): { selector: string; locatorType: 'css' | 'xpath' } {
    const desc = description.toLowerCase().trim();

    // Check for explicit selectors first
    if (description.startsWith('#') || description.startsWith('.') || description.startsWith('[')) {
      return { selector: description, locatorType: 'css' };
    }

    // Handle specific field types
    if (desc.includes('email')) {
      return { selector: 'input[type="email"]', locatorType: 'css' };
    }
    if (desc.includes('password')) {
      return { selector: 'input[type="password"]', locatorType: 'css' };
    }
    if (desc.includes('search')) {
      return { selector: 'input[type="search"]', locatorType: 'css' };
    }

    // Try attribute-based matching first
    const cleanDesc = this.escapeForCSS(desc.replace(/^the\s+/i, ''));
    const cssSelector = `input[name*="${cleanDesc}"], input[id*="${cleanDesc}"], input[placeholder*="${cleanDesc}"], textarea[name*="${cleanDesc}"], textarea[id*="${cleanDesc}"]`;
    
    return { selector: cssSelector, locatorType: 'css' };
  }

  /**
   * Generate selector for clickable elements (buttons, links)
   */
  private static generateClickSelector(description: string): { selector: string; locatorType: 'css' | 'xpath' } {
    const desc = description.toLowerCase().trim();

    // Check for explicit selectors first
    if (description.startsWith('#') || description.startsWith('.') || description.startsWith('[')) {
      return { selector: description, locatorType: 'css' };
    }

    // For buttons and links, use XPath for text matching (case-insensitive)
    const cleanDesc = description.replace(/^the\s+/i, '').trim();
    const escapedText = this.escapeForXPath(cleanDesc);

    // Case-insensitive XPath using translate function
    const upperCase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowerCase = 'abcdefghijklmnopqrstuvwxyz';
    
    const xpathSelector = `//button[contains(translate(normalize-space(.), '${upperCase}', '${lowerCase}'), '${escapedText.toLowerCase()}')] | //input[@type='button' and contains(translate(@value, '${upperCase}', '${lowerCase}'), '${escapedText.toLowerCase()}')] | //input[@type='submit' and contains(translate(@value, '${upperCase}', '${lowerCase}'), '${escapedText.toLowerCase()}')] | //a[contains(translate(normalize-space(.), '${upperCase}', '${lowerCase}'), '${escapedText.toLowerCase()}')]`;

    return { selector: xpathSelector, locatorType: 'xpath' };
  }

  /**
   * Generate selector for text verification
   */
  private static generateTextSelector(elementDesc: string, expectedText: string): { selector: string; locatorType: 'css' | 'xpath' } {
    // For text verification, create a simple XPath that looks for elements containing the text
    const escapedText = this.escapeForXPath(expectedText);
    const upperCase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowerCase = 'abcdefghijklmnopqrstuvwxyz';
    
    const xpathSelector = `//*[contains(translate(normalize-space(.), '${upperCase}', '${lowerCase}'), '${escapedText.toLowerCase()}')]`;
    
    return { selector: xpathSelector, locatorType: 'xpath' };
  }

  /**
   * Escape text for safe use in CSS selectors
   */
  private static escapeForCSS(text: string): string {
    return text.replace(/["\\]/g, '\\$&');
  }

  /**
   * Escape text for safe use in XPath expressions
   */
  private static escapeForXPath(text: string): string {
    // If text contains only single quotes, wrap in double quotes
    if (!text.includes('"')) {
      return `"${text}"`;
    }
    // If text contains only double quotes, wrap in single quotes
    if (!text.includes("'")) {
      return `'${text}'`;
    }
    // If text contains both, use concat()
    const parts = text.split('"').map(part => `'${part}'`);
    return `concat(${parts.join(', \'"\', ')})`;
  }

  /**
   * Batch parse multiple test steps
   */
  static parseTestSteps(steps: string[]): ParsedTestStep[] {
    return steps.map(step => this.parseTestStep(step));
  }

  /**
   * Validate if a test step can be parsed
   */
  static canParse(step: string): boolean {
    const parsed = this.parseTestStep(step);
    return parsed.action !== 'unknown';
  }

  /**
   * Get suggested improvements for unparseable steps
   */
  static getSuggestion(step: string): string {
    const suggestions = [
      "Try using these patterns:",
      "• Navigate to [URL]",
      "• Click the [button/link name]", 
      "• Type '[text]' in the [field name]",
      "• Verify the title contains '[expected text]'",
      "• Wait for 3 seconds"
    ];
    
    return suggestions.join('\n');
  }
}