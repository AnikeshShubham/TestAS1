# TestFlow - Automated Testing Platform

## Overview

TestFlow is a web-based test automation platform that allows users to create, execute, and monitor browser tests using human-readable test steps. The platform converts plain English test descriptions into executable browser automation commands, making test creation accessible to both technical and non-technical users. It features real-time test execution monitoring, detailed reporting with screenshots and logs, and a modern Material Design 3 interface optimized for efficiency and data density.

## Recent Changes

### September 19, 2025 - Project Import and OpenAI Enhancement
- **Project Setup**: Successfully imported TestFlow from GitHub and configured for Replit environment
- **OpenAI Integration**: Added intelligent test step parsing and execution using OpenAI API (gpt-5 model)
- **Enhanced Test Execution**: Multi-step test descriptions are now automatically broken down into individual executable steps
- **Real-time Logging**: Improved execution logs with emojis, detailed feedback, and helpful troubleshooting tips
- **Smart Fallback System**: Graceful fallback to basic parsing when OpenAI is unavailable
- **Workflow Configuration**: Set up development server on port 5000 with proper host configuration for Replit proxy
- **Deployment Ready**: Configured for autoscale deployment with build and run commands
- **Environment Setup**: Node.js 20, npm dependencies installed, OpenAI API key configured

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite for build tooling and development server
- **UI Framework**: Tailwind CSS with shadcn/ui component library based on Radix UI primitives
- **Design System**: Material Design 3 principles with custom color palette for test states (success: green, error: red, warning: yellow, primary: deep blue)
- **State Management**: TanStack Query for server state management and data fetching
- **Routing**: Wouter for lightweight client-side routing
- **Theme Support**: Custom theme provider with light/dark mode toggle and localStorage persistence

### Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **API Structure**: RESTful API with `/api` prefix for all routes
- **Development**: Hot module replacement via Vite integration in development mode
- **Build**: esbuild for server-side bundling and deployment

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL instance
- **Schema Design**: 
  - Test Suites: Collections of related test steps
  - Test Steps: Individual automation commands with execution order
  - Test Runs: Execution instances of test suites with status tracking
  - Test Step Results: Individual step execution results with timing, logs, and screenshots
- **Development Storage**: In-memory storage implementation for local development and testing

### Test Automation Engine
- **OpenAI Integration**: AI-powered test step parsing using GPT-5 model for complex multi-step test descriptions
- **Enhanced Parser**: Custom test step parser with fallback to basic parsing when AI is unavailable
- **Supported Actions**: Navigation, clicking, typing, verification, waiting, scrolling, form interactions
- **Selector Generation**: Intelligent CSS and XPath selector generation from natural language element descriptions
- **Real-time Execution**: Enhanced logging with emojis, detailed feedback, and troubleshooting tips
- **Browser Automation**: Architecture prepared for Puppeteer integration for headless browser control

### Authentication and Authorization
- **Session Management**: Express sessions with PostgreSQL session store using connect-pg-simple
- **Security**: CORS handling and request/response logging middleware
- **Error Handling**: Centralized error handling with structured error responses

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL hosting with connection pooling
- **Drizzle Kit**: Database migrations and schema management
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Styling Dependencies
- **Radix UI**: Comprehensive set of accessible component primitives (accordion, dialog, dropdown, etc.)
- **Tailwind CSS**: Utility-first CSS framework with PostCSS integration
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Type-safe component variant management

### Development and Build Tools
- **Vite**: Frontend build tool with hot module replacement and development server
- **esbuild**: Fast JavaScript bundler for production server builds
- **TypeScript**: Static type checking across client and server code
- **Replit Integration**: Development environment integration with runtime error modal and cartographer plugins

### Form and Data Handling
- **React Hook Form**: Form state management with @hookform/resolvers for validation
- **Zod**: Schema validation library integrated with Drizzle ORM
- **date-fns**: Date manipulation and formatting utilities

### Testing Infrastructure
- **Test Step Parser**: Custom parser for converting natural language to automation commands
- **Execution Engine**: Real-time test execution with progress tracking and result capture
- **Screenshot Capture**: Image capture capabilities for test evidence and debugging