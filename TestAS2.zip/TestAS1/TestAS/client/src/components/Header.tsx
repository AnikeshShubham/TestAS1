import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Moon, Sun, Play, History, Settings } from 'lucide-react';

interface HeaderProps {
  onThemeToggle?: () => void;
  isDark?: boolean;
}

export default function Header({ onThemeToggle, isDark = false }: HeaderProps) {
  const [activeTab, setActiveTab] = useState<'tests' | 'history' | 'settings'>('tests');

  const handleTabClick = (tab: 'tests' | 'history' | 'settings') => {
    setActiveTab(tab);
    console.log(`Navigated to ${tab} tab`);
  };

  return (
    <header className="flex items-center justify-between p-4 border-b bg-background">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Play className="w-4 h-4 text-primary-foreground" />
          </div>
          <h1 className="text-xl font-semibold">TestFlow</h1>
        </div>
        
        <nav className="flex items-center gap-1">
          <Button
            variant={activeTab === 'tests' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => handleTabClick('tests')}
            className="flex items-center gap-2"
            data-testid="nav-tests"
          >
            <Play className="w-4 h-4" />
            Tests
          </Button>
          <Button
            variant={activeTab === 'history' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => handleTabClick('history')}
            className="flex items-center gap-2"
            data-testid="nav-history"
          >
            <History className="w-4 h-4" />
            History
          </Button>
          <Button
            variant={activeTab === 'settings' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => handleTabClick('settings')}
            className="flex items-center gap-2"
            data-testid="nav-settings"
          >
            <Settings className="w-4 h-4" />
            Settings
          </Button>
        </nav>
      </div>

      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => {
            onThemeToggle?.();
            console.log('Theme toggled to:', isDark ? 'light' : 'dark');
          }}
          data-testid="button-theme-toggle"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </Button>
      </div>
    </header>
  );
}