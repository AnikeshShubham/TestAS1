import TestAutomationApp from '../TestAutomationApp';

export default function TestAutomationAppExample() {
  return <TestAutomationApp />;
}