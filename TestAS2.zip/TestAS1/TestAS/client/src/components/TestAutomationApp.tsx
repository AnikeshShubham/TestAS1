import { useState, useEffect, useRef } from 'react';
import { ThemeProvider, useTheme } from './ThemeProvider';
import Header from './Header';
import TestStepEditor from './TestStepEditor';
import ExecutionDashboard from './ExecutionDashboard';

interface TestStep {
  id: string;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  duration?: number;
  error?: string;
  logs?: string[];
}

function TestAutomationContent() {
  const { theme, toggleTheme } = useTheme();
  const [testSteps, setTestSteps] = useState<TestStep[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [executionSteps, setExecutionSteps] = useState<TestStep[]>([]);
  const [currentTestRunId, setCurrentTestRunId] = useState<string | null>(null);
  const currentTestRunIdRef = useRef<string | null>(null);
  const eventSourceRef = useRef<EventSource | null>(null);

  // Keep ref in sync with state
  useEffect(() => {
    currentTestRunIdRef.current = currentTestRunId;
  }, [currentTestRunId]);

  // Server-Sent Events connection for real-time updates
  useEffect(() => {
    eventSourceRef.current = new EventSource('/api/events');
    
    eventSourceRef.current.onopen = () => {
      console.log('Connected to Server-Sent Events');
    };
    
    eventSourceRef.current.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        handleSSEMessage(message);
      } catch (error) {
        console.error('Error parsing SSE message:', error);
      }
    };
    
    eventSourceRef.current.onerror = (error) => {
      console.error('SSE error:', error);
    };
    
    // Cleanup on unmount
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  const handleSSEMessage = (message: any) => {
    console.log('SSE message received:', message);
    
    // Ignore messages from other test runs (use ref to avoid stale closure)
    if (message.testRunId && currentTestRunIdRef.current && message.testRunId !== currentTestRunIdRef.current) {
      console.log('Ignoring message from different test run:', message.testRunId);
      return;
    }
    
    switch (message.type) {
      case 'connected':
        // Initial connection message, no action needed
        break;
        
      case 'test_run_started':
        if (message.testRunId === currentTestRunIdRef.current) {
          setIsRunning(true);
        }
        break;
        
      case 'step_started':
        if (message.testRunId === currentTestRunIdRef.current) {
          setExecutionSteps(prev => prev.map(step => 
            step.id === `step-${message.stepOrder}` 
              ? { ...step, status: 'running' as const }
              : step
          ));
        }
        break;
        
      case 'step_completed':
        if (message.testRunId === currentTestRunIdRef.current) {
          const result = message.result;
          setExecutionSteps(prev => prev.map(step => 
            step.id === `step-${message.stepOrder}`
              ? {
                  ...step,
                  status: result.status as 'passed' | 'failed',
                  duration: result.duration,
                  error: result.errorMessage || undefined,
                  logs: result.logs || []
                }
              : step
          ));
        }
        break;
        
      case 'test_run_completed':
        if (message.testRunId === currentTestRunIdRef.current) {
          setIsRunning(false);
          setCurrentTestRunId(null);
          console.log(`Test execution ${message.status}: ${message.passedSteps} passed, ${message.failedSteps} failed`);
        }
        break;
        
      case 'test_run_error':
        if (message.testRunId === currentTestRunIdRef.current) {
          setIsRunning(false);
          setCurrentTestRunId(null);
          console.error('Test run error:', message.error);
        }
        break;
    }
  };

  const handleRunTests = async (steps: TestStep[]) => {
    if (isRunning) {
      console.log('Test execution already in progress');
      return;
    }

    try {
      // First create a test suite if we don't have one
      let testSuiteId = 'temp-suite-' + Date.now();
      
      try {
        const suiteResponse = await fetch('/api/test-suites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: 'Ad-hoc Test Run',
            description: 'Test suite created for immediate execution'
          })
        });
        
        if (suiteResponse.ok) {
          const suite = await suiteResponse.json();
          testSuiteId = suite.id;
        }
      } catch (error) {
        console.warn('Could not create test suite, using temporary ID:', error);
      }

      // Prepare steps for execution - add step order and IDs
      const preparedSteps = steps.map((step, index) => ({
        ...step,
        id: `step-${index + 1}`,
        status: 'pending' as const
      }));
      
      setExecutionSteps(preparedSteps);
      
      console.log('Starting real test execution with steps:', steps);
      
      // Start the test execution via API
      const response = await fetch(`/api/test-suites/${testSuiteId}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ steps: preparedSteps })
      });

      if (!response.ok) {
        throw new Error(`Failed to start test execution: ${response.statusText}`);
      }

      const result = await response.json();
      setCurrentTestRunId(result.testRunId);
      setIsRunning(true); // Set immediately for better UX
      console.log('Test execution started:', result);
      
    } catch (error) {
      console.error('Failed to start test execution:', error);
      setIsRunning(false);
    }
  };

  const handleStepsChange = (steps: TestStep[]) => {
    setTestSteps(steps);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header onThemeToggle={toggleTheme} isDark={theme === 'dark'} />
      
      <main className="container mx-auto p-6 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <h2 className="text-lg font-semibold mb-4">Create Test Steps</h2>
            <TestStepEditor
              onRunTests={handleRunTests}
              onStepsChange={handleStepsChange}
              isRunning={isRunning}
            />
          </div>
          
          <div>
            <h2 className="text-lg font-semibold mb-4">Execution Dashboard</h2>
            <ExecutionDashboard
              steps={executionSteps}
              isRunning={isRunning}
            />
          </div>
        </div>
        
        {executionSteps.length > 0 && (
          <div className="mt-8">
            <div className="text-sm text-muted-foreground text-center p-4 border rounded-md bg-muted/50">
              🚀 Real test automation would execute these steps using Puppeteer or Selenium.
              <br />
              Steps like "Navigate to URL", "Click element", "Verify text" would interact with actual web pages.
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default function TestAutomationApp() {
  return (
    <ThemeProvider>
      <TestAutomationContent />
    </ThemeProvider>
  );
}