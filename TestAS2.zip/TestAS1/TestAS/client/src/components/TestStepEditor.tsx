import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Play, Plus, Trash2 } from 'lucide-react';

interface TestStep {
  id: string;
  description: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
}

interface TestStepEditorProps {
  onRunTests?: (steps: TestStep[]) => void;
  onStepsChange?: (steps: TestStep[]) => void;
  isRunning?: boolean;
}

export default function TestStepEditor({ onRunTests, onStepsChange, isRunning = false }: TestStepEditorProps) {
  const [steps, setSteps] = useState<TestStep[]>([
    { id: '1', description: 'Navigate to https://example.com', status: 'pending' },
    { id: '2', description: 'Click the "Get Started" button', status: 'pending' },
    { id: '3', description: 'Verify the page title contains "Welcome"', status: 'pending' }
  ]);
  const [newStepText, setNewStepText] = useState('');

  const handleAddStep = () => {
    if (newStepText.trim()) {
      const newStep: TestStep = {
        id: Date.now().toString(),
        description: newStepText.trim(),
        status: 'pending'
      };
      const updatedSteps = [...steps, newStep];
      setSteps(updatedSteps);
      setNewStepText('');
      onStepsChange?.(updatedSteps);
      console.log('Added new test step:', newStep.description);
    }
  };

  const handleRemoveStep = (stepId: string) => {
    const updatedSteps = steps.filter(step => step.id !== stepId);
    setSteps(updatedSteps);
    onStepsChange?.(updatedSteps);
    console.log('Removed test step with id:', stepId);
  };

  const handleRunTests = () => {
    onRunTests?.(steps);
    console.log('Running tests with', steps.length, 'steps');
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Test Steps
          <Button 
            onClick={handleRunTests} 
            disabled={isRunning || steps.length === 0}
            className="flex items-center gap-2"
            data-testid="button-run-tests"
          >
            <Play className="w-4 h-4" />
            {isRunning ? 'Running...' : 'Run Tests'}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center gap-2 p-3 border rounded-md hover-elevate">
              <span className="text-sm text-muted-foreground min-w-[2rem]">
                {index + 1}.
              </span>
              <span className="font-mono text-sm flex-1" data-testid={`text-step-${step.id}`}>
                {step.description}
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleRemoveStep(step.id)}
                disabled={isRunning}
                className="h-8 w-8"
                data-testid={`button-remove-step-${step.id}`}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
        
        <div className="flex gap-2">
          <Textarea
            placeholder="Enter a test step (e.g., Click the login button, Navigate to /dashboard, Verify text contains 'Success')"
            value={newStepText}
            onChange={(e) => setNewStepText(e.target.value)}
            disabled={isRunning}
            className="resize-none"
            rows={2}
            data-testid="input-new-step"
          />
          <Button
            onClick={handleAddStep}
            disabled={!newStepText.trim() || isRunning}
            size="icon"
            className="self-start mt-0"
            data-testid="button-add-step"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}